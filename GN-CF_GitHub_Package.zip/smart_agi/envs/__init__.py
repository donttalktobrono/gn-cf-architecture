"""Environment implementations"""
