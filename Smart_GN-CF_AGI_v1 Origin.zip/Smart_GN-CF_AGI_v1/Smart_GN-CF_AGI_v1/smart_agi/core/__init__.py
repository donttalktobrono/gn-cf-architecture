"""Core neural components"""
