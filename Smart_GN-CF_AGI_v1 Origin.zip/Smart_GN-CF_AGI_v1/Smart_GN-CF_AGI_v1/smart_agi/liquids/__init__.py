"""Liquid skill clustering system"""
